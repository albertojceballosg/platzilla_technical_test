<?php
	require_once ('include/platzilla/Managers/ModuleManager.php');

	class WebmailInstaller {
		const MODULE_NAME = 'webmail';

		private static $INSTANCE = null;

		private function buildSqlStatementsToCreateTables () {
			return array_merge (
				$this->buildSqlStatementsToDropTables (),
				array (
					'CREATE TABLE IF NOT EXISTS vtiger_webmail_providers (
						name VARCHAR(50) NOT NULL,
						label VARCHAR(50) NOT NULL,
						incomingprotocol VARCHAR(15) NOT NULL,
						incominghostname VARCHAR(50) NOT NULL,
						incomingport INT(11) NOT NULL,
						incomingsecuritytype VARCHAR(15) NULL DEFAULT NULL,
						incomingauthenticationmethod VARCHAR(15) NOT NULL,
						outgoingprotocol VARCHAR(15) NOT NULL,
						outgoinghostname VARCHAR(50) NOT NULL,
						outgoingport INT(11) NOT NULL,
						outgoingsecuritytype VARCHAR(15) NULL DEFAULT NULL,
						outgoingauthenticationmethod VARCHAR(15) NOT NULL,
						PRIMARY KEY (name)
					) ENGINE=InnoDB',
					'CREATE TABLE  IF NOT EXISTS vtiger_webmail_users (
						userid INT(11) NOT NULL,
						provider VARCHAR(50) NOT NULL,
						fullname VARCHAR(255) NOT NULL,
						email VARCHAR(255) NOT NULL,
						username VARCHAR(255) NOT NULL,
						password VARCHAR(255) NOT NULL,
						receivedfolder VARCHAR(50) NOT NULL,
						sentfolder VARCHAR(50) NOT NULL,
						lastreceivedmessageuid INT(11) NULL DEFAULT NULL,
						lastsentmessageuid INT(11) NULL DEFAULT NULL,
						lastsyncedon DATETIME NULL DEFAULT NULL,
						lasterror VARCHAR(255) NULL DEFAULT NULL,
						PRIMARY KEY (userid, provider),
						INDEX FK_vtiger_webmail_users_vtiger_webmail_providers (provider),
						CONSTRAINT FK_vtiger_webmail_users_vtiger_webmail_providers FOREIGN KEY (provider) REFERENCES vtiger_webmail_providers (name) ON UPDATE CASCADE ON DELETE CASCADE,
						CONSTRAINT FK_vtiger_webmail_users_vtiger_users_mail FOREIGN KEY (userid) REFERENCES vtiger_users (id) ON UPDATE CASCADE ON DELETE CASCADE
					) ENGINE=InnoDB',
					'CREATE TABLE  IF NOT EXISTS vtiger_webmail_usersmodules (
						userid INT(11) NOT NULL,
						provider VARCHAR(50) NOT NULL,
						modulename VARCHAR(25) NOT NULL,
						PRIMARY KEY (userid, provider, modulename),
						INDEX FK_vtiger_webmail_usersmodules_vtiger_tab (modulename),
						CONSTRAINT FK_vtiger_webmail_usersmodules_vtiger_tab FOREIGN KEY (modulename) REFERENCES vtiger_tab (name) ON UPDATE CASCADE ON DELETE CASCADE,
						CONSTRAINT FK_vtiger_webmail_usersmodules_vtiger_webmail_users FOREIGN KEY (userid, provider) REFERENCES vtiger_webmail_users (userid, provider) ON UPDATE CASCADE ON DELETE CASCADE
					) ENGINE=InnoDB',
				)
			);
		}

		private function buildSqlStatementsToDropTables () {
			return array (
				'DROP TABLE IF EXISTS vtiger_webmail_usersmodules',
				'DROP TABLE IF EXISTS vtiger_webmail_users',
				'DROP TABLE IF EXISTS vtiger_webmail_providers',
			);
		}

		private function buildSqlStatementsToPopulateTables () {
			return array (
				"INSERT INTO vtiger_webmail_providers (name, label, incomingprotocol, incominghostname, incomingport, incomingsecuritytype, incomingauthenticationmethod, outgoingprotocol, outgoinghostname, outgoingport, outgoingsecuritytype, outgoingauthenticationmethod)
				VALUES ('Outlook', 'Microsoft Outlook Mail', 'IMAP', 'imap-mail.outlook.com', 993, 'ssl', 'plain', 'SMTP', 'smtp-mail.outlook.com', 587, 'tls', 'plain')",
				"INSERT INTO vtiger_webmail_providers (name, label, incomingprotocol, incominghostname, incomingport, incomingsecuritytype, incomingauthenticationmethod, outgoingprotocol, outgoinghostname, outgoingport, outgoingsecuritytype, outgoingauthenticationmethod)
				VALUES ('Platzilla', 'Platzilla', 'IMAP', 'mail.timemanagement.es', 993, 'tls', 'plain', 'SMTP', 'mail.timemanagement.es', 587, 'TLS', 'plain')",
			);
		}

		public function install (PearDatabase $adb) {
			$this->uninstall ($adb);

			ModuleManager::getInstance ($adb)->saveModule (
				Module::getInstance ()
					->setLabel ('Webmail')
					->setName (self::MODULE_NAME)
					->setPresence (ModuleInterface::PRESENCE_VISIBLE)
					->setShowInAdminConsole (true)
					->setType (ModuleInterface::TYPE_TOOL)
			);
		}

		public function runPostInstallTasks (PearDatabase $adb) {
			$sqlStatements = array_merge (
				$this->buildSqlStatementsToCreateTables (),
				$this->buildSqlStatementsToPopulateTables ()
			);
			if (empty ($sqlStatements)) {
				return;
			}
			$adb->query ('START TRANSACTION');
			foreach ($sqlStatements as $sqlStatement) {
				$adb->query ($sqlStatement);
			}
			$adb->query ('COMMIT');
		}

		public function runPreUninstallTasks (PearDatabase $adb) {
			$sqlStatements = $this->buildSqlStatementsToDropTables ();
			if (empty ($sqlStatements)) {
				return;
			}
			$adb->query ('START TRANSACTION');
			foreach ($sqlStatements as $sqlStatement) {
				$adb->query ($sqlStatement);
			}
			$adb->query ('COMMIT');
		}

		public function uninstall (PearDatabase $adb) {
			$mm     = ModuleManager::getInstance ($adb);
			$module = $mm->fetchModule (self::MODULE_NAME);
			if (empty ($module)) {
				return;
			}
			$mm->deleteModule ($module);
		}

		public static function getInstance () {
			if (self::$INSTANCE == null) {
				self::$INSTANCE = new self ();
			}
			return self::$INSTANCE;
		}

	}
